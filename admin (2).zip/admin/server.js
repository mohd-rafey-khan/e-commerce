// this is for backend
const express = require('express');
const bodyparser = require('body-parser');
const ejs = require('ejs');
var path = require('path');
const upload = require('express-fileupload');
const app = express();

app.use(upload());
app.use(bodyparser.urlencoded({
  extended:true
}));
var datastatus;
var successupload = "You should Post Your Content Here !";
// import mysql package
var mysql = require('mysql');
// connect mysql database
var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:"",
    database:"commercialweb"
});

// check whether it is connect or not
con.connect(function(err) {
  if(err) throw err;
    console.log("database connect sucessfully...");

});

app.use(express.static('public'));
app.set("view engine",'ejs');

// admin route
app.get("/",function(req,res) {
   res.render("home");
});
app.get("/dash-admin",function(req,res) {
  res.render("admin/dashboard");
});
app.get("/categoryadd",function(req,res) {

  // fetch data into category table
  var query = "SELECT * FROM category";
  con.query(query, function (err, result) {
   if (err) throw err;
   console.log(result);
   console.log(result.length);
   res.render("admin/addcategory.ejs",{filestatus:successupload,response:result});
   });
});
app.post("/categoryadd",function(req,res){
   console.log(req.body.catimg);
   console.log(req.files.catimg);
   // res.send("sucessfully");
   var category_name = req.body.catname;
   var category_img_name = req.files.catimg.name;
   var filesize = req.files.catimg.size;
   var filemd5 = req.files.catimg.md5;
   if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }
  // save into category table on commercialweb database

  var insertquery = "INSERT INTO category (name , image) VALUES (?, ?)";
  var query = mysql.format(insertquery,[category_name,category_img_name]);

  con.query(query, function (err, result) {
   if (err) throw err;
   console.log("1 record inserted");
   });

  // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
  let sampleFile = req.files.catimg;
  // Use the mv() method to place the file somewhere on your server
  var dirpath = "/public/upload/"+category_img_name;
  sampleFile.mv(path.join(__dirname,dirpath), function(err) {

      if (err)
      return res.status(500).send(err);
      successupload  = "Sucessfully Upload Your Post";
      res.redirect("/categoryadd");
  });
});
app.get("/addproduct",function(req,res) {

   var length;
   var responselist;
   // fetch data of category table form commercialweb;
    var query = "SELECT * FROM category";
    con.query(query,function(err,responsecategory) {
        if(err) throw err;
        var queryforproduct = "SELECT *FROM product";
        con.query(queryforproduct,function(err,responseproduct) {
          if(err) throw err;
          // console.log(responseproduct);
          res.render("admin/addproduct.ejs",{categorylist:responsecategory,productlist:responseproduct});

        });

    });
});
app.post("/addproduct",function(req,res) {
   // var product_name = req.body
   console.log(req.body);
   console.log(req.files.prodimg1);
   console.log(req.files.prodimg2);
   console.log(req.files.prodimg3);
  //image uploaded variable display Status of Quantity
  var totalimg ;
  // save into product table on commercialweb database
  var prodname = req.body.prodname;
  var prodprice = req.body.prodprice;
  var prodcategory = req.body.prodcategory;
  var description = req.body.desc;
  var nameimg1 = "";
  var nameimg2 = "";
  var nameimg3 = "";
  if(!req.files.prodimg1){
    res.send("please insert image 1");
  }
  else{
    // variable to handle image : 1
    var nameimg1 = req.files.prodimg1.name;
    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.prodimg1;
    // Use the mv() method to place the file somewhere on your server
    var dirpath = "/public/upload/product/"+nameimg1;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {

        if (err)
        return res.status(500).send(err);
        // successupload  = "Sucessfully Upload Your Post";
        totalimg = 1;
    });
  }
  if(req.files.prodimg2){
    // variable to handle image : 2
    var nameimg2 = req.files.prodimg2.name;
    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.prodimg2;
    // Use the mv() method to place the file somewhere on your server
    var dirpath = "/public/upload/product/"+nameimg2;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {

        if (err)
        return res.status(500).send(err);
        // successupload  = "Sucessfully Upload Your Post";
        totalimg ++;
    });
  }
  if(req.files.prodimg3){
    // variable to handle image : 3
    var nameimg3 = req.files.prodimg3.name;
    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.prodimg3;
    // Use the mv() method to place the file somewhere on your server
    var dirpath = "/public/upload/product/"+nameimg3;
    sampleFile.mv(path.join(__dirname,dirpath), function(err) {

        if (err)
        return res.status(500).send(err);
        // successupload  = "Sucessfully Upload Your Post";
        totalimg ++;
    });
  }

  // insert data into product table
  var insertquery = "INSERT INTO product (name, price, category, description, image1, image2, image3) VALUES (?, ?, ?, ?, ?, ?, ?)";
  var query = mysql.format(insertquery,[prodname, prodprice, prodcategory, description, nameimg1, nameimg2, nameimg3]);

  con.query(query, function (err, result) {
   if (err) throw err;
   console.log("1 record inserted into product table");
   });

   res.send(totalimg);
});

app.post("/delete",function(req,res) {
  console.log(req.body);
  var delete_content = req.body.delete;
  var query = "DELETE FROM product WHERE product_id =?";
  con.query(query,[delete_content],function (err, result) {
     if(err) throw err;
     console.log(result);
     res.send(result);
  });
});
// user route
app.get("/create",function(req,res) {
   res.render("user/home",{status:datastatus});
});
app.post("/create",function(req,res) {
   var name = req.body.name;
   var email = req.body.email;
   var address = req.body.address;
   var contact = req.body.contact;
   var password = req.body.password;

   console.log(name);
   console.log(email);
   console.log(address);
   console.log(contact);
   console.log(password);

   var checkquery = "SELECT email FROM login";
   con.query(checkquery,function(err,response) {
     for(var i = 0;i<= response.length-1;i++){
        if(response[i].email === email){
          datastatus = "Sorry we have already acount on this Email..";
          res.redirect("/create");
          break;
        }else{
           insertData();
           break;
        }
     }
   });
   function insertData() {
     var insertquery = "INSERT INTO login (name , email , address , contact , password ) VALUES (?, ?, ?, ?, ?)";
     var query = mysql.format(insertquery,[name,email,address,contact,password]);

     con.query(query, function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
      datastatus = "Sucessfully Insert"
      res.redirect("/create");
      });
   }

});
app.post("/login",function(req,res){
   var email = req.body.email;
   var pass = req.body.password;
   var searchquery = "SELECT *FROM login WHERE email = ? AND password = ?";
   con.query(searchquery,[email,pass],function(err,response) {
     if(err) throw err;
     if(!response){
       res.send("Please check your email or password.");
     }
     else {
       if(response[0].email === email && response[0].password === pass){
         console.log("sucessfully");
         res.send("sucessfully login..");
       }
     }
   });
});




app.listen(4000,function(req,res) {
   console.log("Server is started at 4000...");
});
