const express = require('express');
// const upload = require('express-fileupload');

var router = express.Router();
var mysql = require('mysql');
var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:"",
    database:"commercialweb"
});

router.get("/",function(req,res) {

  var query = "SELECT * FROM blog";
  con.query(query,function(err,response) {
    if(err) throw err;

    res.render("blog/bloghome.ejs",{blogdata:response});
  });
  // res.send("home");
});

// router.get("/about",function(req,res) {
//   res.send("about");
// });
//
// router.get("/contact",function(req,res) {
//   res.send("contact");
// });

// router.get("/compose",function(req,res) {
//   res.render('admin/blogadmin.ejs');
// });
//
// router.post("/compose",function(req,res) {
//   var blog_post_title = req.body.title;
//   var blog_post_desc = req.body.blogdesc;
//   var blog_post_img = req.body.blogpostimg;
//   var insertquery = "INSERT INTO blog (title , image, desc_post) VALUES (?, ?, ?)";
//   var query = mysql.format(insertquery,[blog_post_title,blog_post_img,blog_post_desc]);
//
//   con.query(query, function (err, result) {
//    if (err) throw err;
//    console.log("1 record inserted");
//    // res.redirect("/compose");
//    res.render('admin/blogadmin.ejs');
//
//    });
//   // console.log(req.body);
//   // res.send("compose");
// });

module.exports = router;
