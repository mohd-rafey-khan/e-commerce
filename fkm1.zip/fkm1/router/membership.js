const express = require('express');
// const path = require('path');
var mysql = require('mysql');
// connect mysql database
var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:"",
    database:"commercialweb"
});
// const bodyparser = require('body-parser');
var router = express.Router();

router.get("/",function(req,res) {
  res.render('membership/registermember.ejs',{status:"",contact:""});
});
router.get("/login",function(req,res) {
  res.render('membership/memberlogin.ejs',{status:""});
});
router.post("/login",function(req,res) {
  var email = req.body.email;
  var password = req.body.pass;
  var query = "SELECT * FROM userlogin WHERE email = ? AND password = ?";
  con.query(query,[email,password],function(err,respond) {
     if(respond.length === 0){
       res.render('membership/memberlogin.ejs',{status:"Please Create Your Acccount on this Email"});
     }
      if(respond[0].email === email && respond.password === password){
        res.render("home");
      }
  });
});
router.post("/",function(req,res) {
  console.log(req.body);
  var name = req.body.name;
  var email = req.body.email;
  var pass = req.body.password;
  var contact = req.body.contact;
  var address = req.body.address;
  var checkquery = "SELECT * FROM userlogin WHERE email=?";
  con.query(checkquery,[email],function(err,response) {
    if(response.length === 0){
      insertData();
    }else{
        if(response){
          var message = "Email already Exists";
          res.render("membership/registermember.ejs",{status:message,contact:""});
        }else{
          insertData();
        }

    }
  });
  function insertData() {
    var member = "normal";
    var insertquery = "INSERT INTO userlogin (name , email , password , contact , address,member ) VALUES (?, ?, ?, ?, ?,?)";
    var query = mysql.format(insertquery,[name,email,pass,contact,address,member]);

    con.query(query, function (err, result) {
     if (err) throw err;
     console.log("1 record inserted");
     var message = "Sucessfully..";
     res.render("membership/registermember.ejs",{status:message,contact:"We will contact you shortly."});
     });
  }


});

router.post('/membership/userupdate',function(req,res) {
  console.log(req.body);
  res.send(req.body);
});
module.exports = router;
