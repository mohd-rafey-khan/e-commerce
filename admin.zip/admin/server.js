// this is for backend
const express = require('express');
const bodyparser = require('body-parser');
const ejs = require('ejs');
var path = require('path');
const app = express();
// const uploads = require('express-fileupload');

// app.use(uploads());
app.use(bodyparser.urlencoded({
  extended:true
}));
var datastatus;
// import mysql package
var mysql = require('mysql');
// connect mysql database
var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:"",
    database:"commercialweb"
});

// check whether it is connect or not
con.connect(function(err) {
  if(err) throw err;
    console.log("database connect sucessfully...");

});

app.use(express.static('public'));
app.set("view engine",'ejs');

// admin route
app.get("/",function(req,res) {
   res.send("Home Page");
});
app.get("/dash-admin",function(req,res) {
  res.render("admin/dashboard");
});
app.get("/manageadd",function(req,res) {
  res.render("admin/addpost.ejs");
});
// app.post("/upload",function(req,res){
//    console.log(req.body);
//    res.send(req.body);
// });



// user route
app.get("/create",function(req,res) {
   res.render("user/home",{status:datastatus});
});
app.post("/create",function(req,res) {
   var name = req.body.name;
   var email = req.body.email;
   var address = req.body.address;
   var contact = req.body.contact;
   var password = req.body.password;

   console.log(name);
   console.log(email);
   console.log(address);
   console.log(contact);
   console.log(password);

   var checkquery = "SELECT email FROM login";
   con.query(checkquery,function(err,response) {
     for(var i = 0;i<= response.length-1;i++){
        if(response[i].email === email){
          datastatus = "Sorry we have already acount on this Email..";
          res.redirect("/create");
          break;
        }else{
           insertData();
           break;
        }
     }
   });
   function insertData() {
     var insertquery = "INSERT INTO login (name , email , address , contact , password ) VALUES (?, ?, ?, ?, ?)";
     var query = mysql.format(insertquery,[name,email,address,contact,password]);

     con.query(query, function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
      datastatus = "Sucessfully Insert"
      res.redirect("/create");
      });
   }

});
app.post("/login",function(req,res){
   var email = req.body.email;
   var pass = req.body.password;
   let flag ="no";
   var searchquery = "SELECT email,password FROM login";
   con.query(searchquery,function(err,response) {
     console.log(response);
     var i = 0;
     while(i!=response.length-1){
       if(response[i].email === email){
         flag= "yes";
         break;
       }
       i++;
     }
   });
   console.log(flag);
   res.send(flag);
   function loginfailed() {
      res.send("sorry check your email or password");
   }
   // res.send("sorry check your email");
});




app.listen(4000,function(req,res) {
   console.log("Server is started at 4000...");
});
